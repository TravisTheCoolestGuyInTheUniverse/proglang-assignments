./compileAndRun.sh testParameters.cpp c++
./compileAndRun.sh testParameters.java java
