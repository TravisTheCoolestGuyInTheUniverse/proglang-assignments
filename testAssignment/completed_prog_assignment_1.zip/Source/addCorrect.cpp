#include <stdlib.h>
#include <iostream>

using namespace std;

int main() {
	int x, y;
	cout << " Enter two integers to be added together." << endl;
	cin >> x >> y;
	cout << " " << x << " + " << y << " = " << x+y << endl;
}