./compile.sh addCorrect c++
./compile.sh addIncorrect c++
./compile.sh addCorrect fortran
./compile.sh addIncorrect fortran

./test.sh addCorrectc
./test.sh addIncorrectc
./test.sh addCorrectf
./test.sh addIncorrectf