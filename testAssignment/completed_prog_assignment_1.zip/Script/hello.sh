#!/bin/bash
read -p "Enter hello followed by world! or whatever the hell you want!" konichiwa sekaii

myfunction() {
    echo "$konichiwa $sekaii"
    echo "this is my function!"
}

myfunction