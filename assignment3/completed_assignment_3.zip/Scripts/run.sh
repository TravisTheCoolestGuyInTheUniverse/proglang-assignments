executable=$1
cd ../Executables
./$executable