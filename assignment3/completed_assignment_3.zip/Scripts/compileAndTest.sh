./compile.sh sort c++
./compile.sh main ada
./test.sh sortc
./test.sh main